# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal, Required, TypedDict

from .cache_control_ephemeral_param import CacheControlEphemeralParam

__all__ = ["ToolBash20250124Param"]


class ToolBash20250124Param(TypedDict, total=False):
    name: Required[Literal["bash"]]
    """Name of the tool.

    This is how the tool will be called by the model and in tool_use blocks.
    """

    type: Required[Literal["bash_20250124"]]

    cache_control: Optional[CacheControlEphemeralParam]
